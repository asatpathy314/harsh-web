export const DemoData = {
  logFile: `2025-04-02 : workout : y :  : 
2025-04-02 : gym : y :  : 
2025-04-02 : meditate : y :  : 
2025-04-02 : read : y :  : 
2025-04-02 : leetcode : y :  : 
2025-04-02 : talk to mom : y :  : 
2025-04-02 : multivitamin : y :  : 
2025-04-02 : magnesium : y :  : 
2025-04-03 : meditate : y :  : 
2025-04-03 : leetcode : y :  : 
2025-04-03 : workout : y :  : 
2025-04-03 : gym : y :  : 
2025-04-03 : talk to mom : y :  : 
2025-04-03 : read : y :  : 
2025-04-03 : multivitamin : y :  : 
2025-04-03 : magnesium : y :  : 
2025-04-04 : leetcode : y :  : 
2025-04-04 : read : y :  : 
2025-04-04 : talk to mom : y :  : 
2025-04-04 : workout : n :  : 
2025-04-04 : gym : n :  : 
2025-04-04 : meditate : n :  : 
2025-04-04 : multivitamin : y :  : 
2025-04-04 : magnesium : y :  : 
2025-04-05 : workout : y :  : 
2025-04-05 : gym : y :  : 
2025-04-05 : meditate : y :  : 
2025-04-05 : talk to mom : y :  : 
2025-04-05 : leetcode : y :  : 
2025-04-05 : read : y :  : 
2025-04-05 : multivitamin : y :  : 
2025-04-05 : magnesium : y :  : 
2025-04-06 : workout : y :  : 
2025-04-06 : leetcode : y :  : 
2025-04-06 : gym : n :  : 
2025-04-06 : talk to mom : y :  : 
2025-04-06 : meditate : y :  : 
2025-04-06 : read : y :  : 
2025-04-06 : multivitamin : y :  : 
2025-04-06 : magnesium : y :  : 
2025-04-07 : leetcode : y :  : 
2025-04-07 : talk to mom : y :  : 
2025-04-07 : workout : y :  : 
2025-04-07 : gym : y :  : 
2025-04-07 : meditate : y :  : 
2025-04-07 : read : y :  : 
2025-04-07 : multivitamin : y :  : 
2025-04-07 : magnesium : y :  : 
2025-04-08 : leetcode : y :  : 
2025-04-08 : workout : y :  : 
2025-04-08 : read : y :  : 
2025-04-08 : talk to mom : y :  : 
2025-04-08 : gym : n :  : 
2025-04-08 : meditate : n :  : 
2025-04-08 : multivitamin : y :  : 
2025-04-08 : magnesium : y :  : 
2025-04-09 : workout : y :  : 
2025-04-09 : gym : n :  : 
2025-04-09 : leetcode : y :  : 
2025-04-09 : talk to mom : y :  : 
2025-04-09 : multivitamin : y :  : 
2025-04-09 : magnesium : y :  : 
2025-04-09 : read : y :  : 
2025-04-09 : meditate : y :  : 
2025-04-10 : workout : y :  : 
2025-04-10 : gym : y :  : 
2025-04-10 : read : y :  : 
2025-04-10 : leetcode : y :  : 
2025-04-10 : talk to mom : y :  : 
2025-04-10 : multivitamin : y :  : 
2025-04-10 : meditate : n :  : 
2025-04-10 : magnesium : y :  : 
2025-04-11 : workout : y :  : 
2025-04-11 : gym : y :  : 
2025-04-11 : meditate : n :  : 
2025-04-11 : read : n :  : 
2025-04-11 : leetcode : y :  : 
2025-04-11 : talk to mom : y :  : 
2025-04-11 : multivitamin : y :  : 
2025-04-11 : magnesium : n :  : `,

  habitsFile: `# This is your habits file.
# It tells harsh what to track and how frequently.
# 1 means daily, 7 means weekly, 14 every two weeks.
# You can also track targets within a set number of days.
# For example, Gym 3 times a week would translate to 3/7.
# 0 is for tracking a habit. 0 frequency habits will not warn or score.
# Examples:

workout: 1
gym: 5/7
meditate: 1
read: 1
leetcode: 1
talk to mom: 1
multivitamin: 1
magnesium: 1`,
}
